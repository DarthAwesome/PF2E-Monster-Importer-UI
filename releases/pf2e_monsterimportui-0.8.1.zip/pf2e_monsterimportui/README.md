# Foundry VTT - PF2E - Monster Import UI
Version 0.8

# Changelog
* Initial release - v0.8

To open: right click the anvil in top-left; using the anvil-menu from https://gitlab.com/Ionshard/foundry-vtt-anvil-menu Thanks!

To use: start pasting the monster into the pane on the left

Still to do:
* Update CSS a bit to use screen real-estate better and allow for wider textarea
* Fix Item ingestion to lookup items in compendiums and use those
* Fix focus spellEntry to import as focus instead of based on actual tradition

* Some interactive way to change actions-type from the preview??
* Some way to insert newlines from the preview??

Need to also update the actual NPC sheet some to import some of these things better :)