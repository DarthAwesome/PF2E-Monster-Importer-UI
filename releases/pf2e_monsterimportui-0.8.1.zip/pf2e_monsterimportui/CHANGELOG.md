#Patch Notes
##0.8.1
* Fix for #1; better parsing of weakness, resistance, immunity
* Better error message if a strike is missing an attack mod
##0.8.0
* Initial Release