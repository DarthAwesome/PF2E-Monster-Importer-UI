import {ilssrahFromBook} from '../../teststrings/testStrings.js'
import { splitMonsterString } from '../utils/monster-string-searching.js'
import { createMonsterStringObject } from '../utils/monster-parser.js'
import { processMonster as createMonsterActor } from '../utils/import_into_fvtt.js'

export class MonsterImportUI extends Application {
    constructor(options){
        super(options)
        //getTemplate()
        this.monsterJSON = undefined
    }
    
    monsterJSON;
    createdMonster;

    /**
     * Assign the default options
     */
    // @ts-ignore
    static get defaultOptions() {
        // @ts-ignore
        const options = super.defaultOptions
        options.id = "pf2e-monster-import-ui"
        options.template = "modules/pf2e_monsterimportui/templates/monster-import-ui.html"
        options.width = 1024
        options.height = 800
        options.resizable = true
        options.classes = ["pf2e-monster-import-ui"]
        options.popOut = true

        return options
    }

    /**
     * Prepare the default data which is required to render
     */
    async getData() {
        let data = {}
        
        return data
    }

    /**
     * Add event listeners to UI elements
     */
    activateListeners(html){
        // const digestButton = $(html).find('.digest-data')
        const textArea = $('.monster-import-ui-container .monster-textarea')
        const errorArea = $('.monster-import-ui-container .error-messages')
        // digestButton.on('click', async event => {
        textArea.on('input', async event => {
            const previewArea = $('.monster-import-ui-container .monster-preview')
            previewArea.empty()
            errorArea.empty()
            const currentMonsterString = $('.monster-import-ui-container .monster-textarea').val().toString()
            if(currentMonsterString!==""){
                try{
                    let monsterObj = createMonsterStringObject(currentMonsterString)
                    this.monsterJSON = monsterObj
                    console.log("Actual monster object",monsterObj)
                    const previewHTML = await renderTemplate('modules/pf2e_monsterimportui/templates/monster-preview.hbs' , {monster: monsterObj})
                    previewArea.append(previewHTML)
                }catch(error) {
                    errorArea.append(error.toString())
                }
            }
        })

        const importButton = $(html).find('.import-monster')
        importButton.on('click', async event => {
            if(!this.monsterJSON) return
            this.createdMonster = await createMonsterActor(this.monsterJSON,undefined,undefined,undefined,true)

            $('.monster-import-ui-container .delete-last-monster .monstername').text(this.createdMonster.name)
        })

        const deleteButton = $(html).find('.delete-last-monster')
        deleteButton.on('click', async event => {
            if(this.createdMonster){
                await this.createdMonster.delete()
                $('.monster-import-ui-container .delete-last-monster .monstername').text("")
                this.createdMonster = undefined
            }
        })


    }
}